#!/bin/bash

echo "Installing plexamp Dependencies"

#requred to end the plugin install
echo "plugininstallend"
